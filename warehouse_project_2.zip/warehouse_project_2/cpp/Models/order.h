#ifndef ORDER_H
#define ORDER_H

#include <string>
#include <cstdlib>

struct Order {
    int id;
    int arrivalTime;
    int dispatchTime = 0;  
    int serviceTime = 0;   
    int priority;
    std::string status;  // Waiting, In Process, Dispatched

    Order(int i, int at, int p)
        : id(i), arrivalTime(at), priority(p), status("Waiting") {
        serviceTime = rand() % 3 + 1;
    }
};

struct OrderCompare {
    bool operator()(const Order& a, const Order& b) {
        return a.arrivalTime > b.arrivalTime; // أقل وقت وصول له أولوية أعلى
    }
};

#endif
