#ifndef VEHICLE_H
#define VEHICLE_H

struct Vehicle {
    int id;

    // الحالة
    bool isAvailable = true;

    // أزمنة التشغيل
    int busyStartTime = 0;
    int busyEndTime = 0;
    int totalBusyTime = 0;

    // السعة
    int capacity = 1;
    int currentLoad = 0;

    Vehicle(int _id, int _capacity = 1)
        : id(_id),
          isAvailable(true),
          busyStartTime(0),
          busyEndTime(0),
          totalBusyTime(0),
          capacity(_capacity),
          currentLoad(0) {}

    double getUtilization(int currentTime) const {
        return currentTime > 0 ? static_cast<double>(totalBusyTime) / currentTime : 0.0;
    }
};

#endif
