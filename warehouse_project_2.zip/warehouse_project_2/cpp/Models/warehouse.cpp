#include "../Models/warehouse.h"

// حاليا كل الوظائف الأساسية في الـ header، ممكن نضيف implement إضافية لو محتاج
