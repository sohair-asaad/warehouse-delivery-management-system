#ifndef WAREHOUSE_H
#define WAREHOUSE_H

#include <queue>
#include <vector>
#include "order.h"
#include "vehicle.h"

struct Warehouse {

std::priority_queue<Order, std::vector<Order>, OrderCompare> priorityQueue;
std::vector<Vehicle> vehicles;

// لتسجيل طول الـ queue عبر الزمن
int totalQueueLength = 0;
int queueSamples = 0;

void recordQueueLength() {
    totalQueueLength += priorityQueue.size();
    queueSamples++;
}

// البحث عن أول عربية متاحة
Vehicle* getAvailableVehicle() {
    for (auto &v : vehicles) {
        if (v.isAvailable) return &v;
    }
    return nullptr;
}

};

#endif