#ifndef ARRIVAL_EVENT_H
#define ARRIVAL_EVENT_H

#include "Event.h"

struct Simulator;

struct ArrivalEvent : public Event {
    Simulator* sim;
    ArrivalEvent(int t, Simulator* s);
    void execute() override;
};

#endif
