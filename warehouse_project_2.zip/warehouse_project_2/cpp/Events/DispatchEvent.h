#ifndef DISPATCH_EVENT_H
#define DISPATCH_EVENT_H

#include "Event.h"

struct Simulator;

struct DispatchEvent : public Event {
    Simulator* sim;
    int time;

    DispatchEvent(int t, Simulator* s);
    void execute() override;
};

#endif
