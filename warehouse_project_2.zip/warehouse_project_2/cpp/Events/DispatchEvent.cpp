#include "../Events/DispatchEvent.h"
#include "../Simulator/Simulator.h"
#include "../Models/order.h"
#include <iostream>

DispatchEvent::DispatchEvent(int t, Simulator* s) {
    time = t;
    sim = s;
}

void DispatchEvent::execute() {
    if (sim->warehouse.priorityQueue.empty()) return;

    // الحصول على أول عربية فاضية
    Vehicle* v = sim->warehouse.getAvailableVehicle();
    if (!v) return;

    // إخراج الطلب من الـ queue
    Order o = sim->warehouse.priorityQueue.top();
    sim->warehouse.priorityQueue.pop();

    // تحديث حالة الطلب
    o.status = "Dispatched";
    o.dispatchTime = sim->currentTime;
    sim->totalWaitingTime += (o.dispatchTime - o.arrivalTime);

    // تحديث حالة العربية
    v->isAvailable = false;
    v->busyStartTime = sim->currentTime;
    v->busyEndTime = sim->currentTime + o.serviceTime;
    v->totalBusyTime += o.serviceTime;

    sim->logs.push_back("Order " + std::to_string(o.id) +
                        " dispatched by Vehicle " + std::to_string(v->id) +
                        " at time " + std::to_string(sim->currentTime));

    std::cout << "DispatchEvent executed at time " << sim->currentTime
              << ", queue size: " << sim->warehouse.priorityQueue.size() << std::endl;

    // جدولة تحرير العربية بعد الخدمة
    sim->scheduleVehicleRelease(v, v->busyEndTime);
}
