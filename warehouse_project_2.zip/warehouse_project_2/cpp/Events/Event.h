#ifndef EVENT_H
#define EVENT_H

struct Event {
    int time;
    virtual void execute() = 0;
    virtual ~Event() {}
};

#endif
