
#include "../Events/ArrivalEvent.h"
#include "../Simulator/Simulator.h"
#include "../Models/order.h"
#include "../Events/DispatchEvent.h"
#include <cstdlib>
#include <string>
#include <iostream>

ArrivalEvent::ArrivalEvent(int t, Simulator* s) {
    time = t;
    sim = s;
}

void ArrivalEvent::execute() {
    // إنشاء طلب جديد
    Order o(sim->nextOrderId++, time, rand() % 3 + 1);
    o.status = "Waiting";

    // إضافة الطلب للـ priority queue
    sim->warehouse.priorityQueue.push(o);

    // تسجيل الـ logs
    sim->logs.push_back("Order " + std::to_string(o.id) + " arrived at time " + std::to_string(time));

    std::cout << "ArrivalEvent executed: Order " << o.id << std::endl;

    // إذا فيه عربية فاضية، جدولة Dispatch
    if (sim->warehouse.getAvailableVehicle() != nullptr) {
        DispatchEvent* d = new DispatchEvent(time, sim);
        sim->scheduleEvent(d);
    }
}
