#include "Simulator/Simulator.h"
#include "Events/ArrivalEvent.h"
#include "Events/DispatchEvent.h"
#include <cstdlib>
#include <ctime>
#include <iostream>
#include "Models/warehouse.h"
#include "Models/order.h"
#include "Models/vehicle.h"

int main() {
    // تهيئة المخزن
    Warehouse wh;

    // إنشاء بعض العربيات
    wh.vehicles.push_back(Vehicle{1});
    wh.vehicles.push_back(Vehicle{2});

    // إضافة طلبات
    Order o1(101, 2, 1);
    Order o2(102, 1, 2);
    Order o3(103, 3, 1);

    wh.priorityQueue.push(o1);
    wh.recordQueueLength(); // نسجل الطول بعد إضافة الطلب الأول

    wh.priorityQueue.push(o2);
    wh.recordQueueLength(); // نسجل الطول بعد الطلب الثاني

    wh.priorityQueue.push(o3);
    wh.recordQueueLength(); // نسجل الطول بعد الطلب الثالث

    // عرض طول الطابور الحالي ومتوسط الطابور
    std::cout << "Current queue size: " << wh.priorityQueue.size() << std::endl;
    double averageQueueLength = wh.queueSamples ? static_cast<double>(wh.totalQueueLength)/wh.queueSamples : 0;
    std::cout << "Average queue length: " << averageQueueLength << std::endl;

    // البحث عن عربية متاحة
    Vehicle* v = wh.getAvailableVehicle();
    if (v != nullptr) {
        std::cout << "Available vehicle ID: " << v->id << std::endl;
    } else {
        std::cout << "No vehicles available!" << std::endl;
    }

    return 0;
}
