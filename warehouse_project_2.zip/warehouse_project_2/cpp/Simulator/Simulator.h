#ifndef SIMULATOR_H
#define SIMULATOR_H

#include <queue>
#include <string>
#include <vector>
#include "../Models/warehouse.h"
#include "../Events/Event.h"

struct EventCompare {
    bool operator()(Event* a, Event* b);
};

struct Simulator {
    Warehouse warehouse;

    int ordersProcessed = 0;
    int totalWaitingTime = 0;
    int currentTime = 0;
    int nextOrderId = 1;

    std::vector<std::string> logs;
    std::priority_queue<Event*, std::vector<Event*>, EventCompare> eventQueue;

    void scheduleEvent(Event* e);
    void scheduleDispatch(int t);
    void scheduleVehicleRelease(Vehicle* v, int releaseTime);

    void run();
    void exportResults();
};

#endif
