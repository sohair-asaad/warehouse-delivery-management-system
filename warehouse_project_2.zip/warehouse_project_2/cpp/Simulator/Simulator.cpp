#include "../Simulator/Simulator.h"
#include "../Events/ArrivalEvent.h"
#include "../Events/DispatchEvent.h"
#include <iostream>
#include <fstream>

bool EventCompare::operator()(Event* a, Event* b) {
    return a->time > b->time; // Min-heap: الأحداث الأصغر زمنياً أولاً
}

void Simulator::scheduleEvent(Event* e) {
    eventQueue.push(e);
}

void Simulator::scheduleDispatch(int t) {
    DispatchEvent* d = new DispatchEvent(t, this);
    scheduleEvent(d);
}

void Simulator::scheduleVehicleRelease(Vehicle* v, int releaseTime) {
    // في هذا المثال البسيط، نرجع السيارة مباشرة بعد انتهاء الخدمة
    v->isAvailable = true;
}

void Simulator::run() {
    while (!eventQueue.empty()) {
        Event* e = eventQueue.top();
        eventQueue.pop();
        currentTime = e->time;
        e->execute();

        warehouse.recordQueueLength();
    }
}

void Simulator::exportResults() {
    std::ofstream file("output.json");
    file << "{\n";
    file << "  \"simulation_time\": " << currentTime << ",\n";
    file << "  \"orders\": {\n";
    file << "    \"processed\": " << ordersProcessed << ",\n";
    file << "    \"average_waiting_time\": " 
         << (ordersProcessed > 0 ? (double)totalWaitingTime / ordersProcessed : 0) << "\n";
    file << "  },\n";

    file << "  \"vehicles\": [\n";
    for (size_t i = 0; i < warehouse.vehicles.size(); i++) {
        Vehicle& v = warehouse.vehicles[i];
        file << "    {\n";
        file << "      \"id\": " << v.id << ",\n";
        file << "      \"utilization\": " << v.getUtilization(currentTime) << "\n";
        file << "    }" << (i + 1 < warehouse.vehicles.size() ? "," : "") << "\n";
    }
    file << "  ],\n";

    file << "  \"warehouse\": {\n";
    file << "    \"average_queue_length\": "
         << (warehouse.queueSamples > 0 ? (double)warehouse.totalQueueLength / warehouse.queueSamples : 0) << "\n";
    file << "  }\n";

    file << "}\n";
    file.close();
    std::cout << "Results exported to output.json\n";
}
